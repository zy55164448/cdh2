package kafka.producer.message;

import java.util.Map;

import kafka.producer.datasource.AnnotationDataSource;

public class MessageAnnotator {
	private final AnnotationDataSource dataSource;
	public MessageAnnotator(AnnotationDataSource dataSource) {
		this.dataSource = dataSource;
	}
	public AnnotatedMessage getAnnotatedMessage(String key,  byte[] body, long reciveTime)
			throws Exception{
		final Map<String , Object> annomap = dataSource.query(key);
		if(annomap == null || annomap.isEmpty()) {
			throw new Exception();
		}
		return new AnnotatedMessage(annomap, key, reciveTime, body);

	}
}
