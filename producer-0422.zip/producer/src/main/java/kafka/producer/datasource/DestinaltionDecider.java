package kafka.producer.datasource;

public class DestinaltionDecider<K, V> {

}
