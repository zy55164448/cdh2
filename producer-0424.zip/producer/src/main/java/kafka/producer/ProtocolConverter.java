package kafka.producer;

import static org.apache.kafka.clients.producer.ProducerConfig.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.function.Supplier;

import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.kafka.clients.producer.Producer;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpRequestDecoder;
import io.netty.handler.codec.http.HttpResponseEncoder;
import kafka.producer.datasource.AnnotationDataSource;
import kafka.producer.datasource.DestinationDataSource;
import kafka.producer.datasource.RedisDataSource;
import kafka.producer.message.MessageAnnotator;
import kafka.producer.message.MessageParser;

public class ProtocolConverter {

	public static GenericObjectPool<Producer<String, byte[]>> errPool = null;
	public static DestinaltionDecider destinaltionDecider =null;
	public static void main(String[] args) throws Exception{
        Properties config = new Properties();
        try(FileInputStream in = new FileInputStream("etc/producer.properties");){
        	config.load(in);
        } catch (IOException exc){
        	System.exit(1);
        	return;
        }
        AnnotationDataSource datasource = new RedisDataSource("127.0.0.1:6379");////////

        DestinationDataSource destDatasource = new DestinationDataSource("127.0.0.1:6379");

        final MessageAnnotator annotator = new MessageAnnotator(datasource);
        final MessageParser parser = new MessageParser(2,6);
        final Supplier<BaseHttpHandler> handlerGenerator = () -> new AnnotedHttpKafkaHandler(
        		parser,
        		"default",
        		annotator,
        		"errTopic");

        EventLoopGroup bossGroup = new NioEventLoopGroup();
        NioEventLoopGroup workerGroup = new NioEventLoopGroup();
        Properties props = new Properties();
        //props.put(BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ACKS_CONFIG, "all");
        props.put(RETRIES_CONFIG, 0);
        props.put(BATCH_SIZE_CONFIG, 25000); // nicht warten
        props.put(LINGER_MS_CONFIG, 200);
        props.put(BUFFER_MEMORY_CONFIG, 33554432);
        props.put(KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props.put(VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.ByteArraySerializer");

        ProducerPoolFactory<String, byte[]> poolFactory = new ProducerPoolFactory<>();////
        destinaltionDecider = new DestinaltionDecider(destDatasource, props, 3, poolFactory);///////
        //errPool = poolFactory.create();/////////
        try {
            ServerBootstrap b = new ServerBootstrap();
            b.group(bossGroup, workerGroup)
            .channel(NioServerSocketChannel.class)
            .localAddress("0.0.0.0", 1883)
            .option(ChannelOption.SO_BACKLOG, 1000)
            .childOption(ChannelOption.TCP_NODELAY, true)
            .childHandler(new ChannelInitializer<SocketChannel>() {

				@Override
				protected void initChannel(SocketChannel ch) throws Exception {
					ChannelPipeline pipeline = ch.pipeline();
					pipeline.addLast("encoder", new HttpResponseEncoder());
					pipeline.addLast("decoder", new HttpRequestDecoder());
					pipeline.addLast("aggregator", new HttpObjectAggregator(1048576));
					pipeline.addLast("handler", handlerGenerator.get());
				}
            }
            );
            ChannelFuture future = b.bind().sync();
            future.channel().closeFuture().sync();

        } finally {
        	bossGroup.shutdownGracefully();
        	workerGroup.shutdownGracefully();
        	bossGroup.terminationFuture().sync();
        	workerGroup.terminationFuture().sync();
        }


	}

}
