minutes = int(input("求めたい分を入力してください："))
print(str(minutes) + "分は" + str(minutes / 60) + "時間です")