package jp.ad.iij.nakam.kafka.sample;

import java.util.Date;
import java.util.Properties;
import java.util.Random;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

public class ProducerSample {

    private long nEvents;
    protected Producer<String, String> producer;

    public static void main(String[] args) {
        ProducerSample ps = new ProducerSample(10);
        ps.start();
    }

    public ProducerSample(long nEvents) {
        this.nEvents = nEvents;
        configure();
    }

    public void configure() {
        Properties props = new Properties();
        props.put("serializer.class", "kafka.serializer.StringEncoder");
        props.setProperty("metadata.broker.list", "localhost:9092");
        ProducerConfig config = new ProducerConfig(props);
        producer = new Producer<String, String>(config);
    }

    public void start() {
        Random rnd = new Random();
        for (long event = 0; event < nEvents; event++) {
            String ip = ". 192.168.2." + rnd.nextInt(255);
            String msg = "task no " + (event + 1) + ip;
            KeyedMessage<String, String> data = new KeyedMessage<String, String>(
                    "page_visits", ip, msg);
            producer.send(data);
            System.out.println(new Date() + " : task no " + (event + 1)
                    + ". send from producer");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
