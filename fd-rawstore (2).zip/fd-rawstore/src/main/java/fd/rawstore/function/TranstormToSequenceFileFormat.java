package fd.rawstore.function;

import java.nio.charset.StandardCharsets;

import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.spark.api.java.function.PairFunction;
import org.spark_project.guava.primitives.Bytes;

import fd.rawstore.bin.CanDataAnnotatedBean;
import scala.Tuple2;

public class TranstormToSequenceFileFormat implements PairFunction<CanDataAnnotatedBean,
    NullWritable, BytesWritable>{
	private static final long serialVersionUID = - 2022345678L;
	private final byte[] delimiter;

	public TranstormToSequenceFileFormat(byte[] delimiter) {
		this.delimiter = delimiter;
	}
	@Override
	public Tuple2<NullWritable, BytesWritable> call(CanDataAnnotatedBean t) throws Exception {
		return new Tuple2<NullWritable, BytesWritable>(NullWritable.get(),new BytesWritable(
				Bytes.concat(
						t.getVin().getBytes(StandardCharsets.UTF_8),this.delimiter,
						Long.toString(t.getRecicvetime()).getBytes(StandardCharsets.UTF_8),this.delimiter,
						t.getMessage()
						))
			);
	}

}
