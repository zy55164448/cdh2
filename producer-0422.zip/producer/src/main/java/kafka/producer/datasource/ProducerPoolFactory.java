package kafka.producer.datasource;

public class ProducerPoolFactory<T1, T2> {

}
