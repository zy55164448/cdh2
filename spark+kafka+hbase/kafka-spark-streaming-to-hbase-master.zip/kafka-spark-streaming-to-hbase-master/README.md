# kafka-spark-streaming-to-hbase
使用spark streaming 导入kafka数据到hbase

本项目依赖于hbrdd, hbrdd是一个方便spark 导入数据到hbase的库.项目地址: [hbrdd](https://github.com/TopSpoofer/hbrdd)

本项目直接使用idea打开即可, 安装和使用本项目, 请访问主页获取更多的帮助: [help](http://www.spoofer.top/2016/04/14/kafka-spark-streaming-to-hbase)
