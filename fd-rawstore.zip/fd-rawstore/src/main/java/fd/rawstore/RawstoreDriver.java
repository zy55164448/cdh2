package fd.rawstore;

import org.apache.spark.streaming.api.java.JavaStreamingContext;

public class RawstoreDriver {

	public static void main(String[] args) {
		JavaStreamingContextCreater creater = new JavaStreamingContextCreater();
		final JavaStreamingContext contex = JavaStreamingContext.getOrCreate("/tmp/chekpoint", creater);

		Runtime.getRuntime().addShutdownHook(new Thread() {
		  @Override
		  public void run() {
			  contex.stop(true,true);
		  }
		});
		contex.start();

		try {
			contex.awaitTermination();
		} catch (InterruptedException e) {

		}

	}

}
