package kafka.producer.datasource;

import java.util.Collections;
import java.util.Map;

import kafka.producer.datasource.RedisConnectionFactory.RedisConnection;
import redis.clients.jedis.JedisCommands;

public class RedisDataSource implements AnnotationDataSource{

	private RedisConnection redis;
	public RedisDataSource(String redisAdress) {
		redis = RedisConnectionFactory.createConnetion(redisAdress);
	}
	@Override
	public Map<String, Object> query(String senderId) {
    	JedisCommands jedisCommands = redis.getInstance();
    	try {
    		Map<String, String> values = jedisCommands.hgetAll(senderId);
    		if (values == null || values.isEmpty()) {
    			return null;
    		}
    		return Collections.<String, Object>unmodifiableMap(values);
    	} finally {
    		redis.returnInstance(jedisCommands);
    	}
	}

}
