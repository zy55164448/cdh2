package kafka.producer;


import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPipeline;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpUtil;
import kafka.producer.message.AnnotatedMessage;
import kafka.producer.message.ErrorMessage;
import kafka.producer.message.MessageAnnotator;
import kafka.producer.message.MessageParser;

public class AnnotedHttpKafkaHandler  extends BaseHttpHandler{
    final MessageParser parser;
    private final String partStrategy;
    final MessageAnnotator annotator;
    private final String erroTopic;

    public AnnotedHttpKafkaHandler(MessageParser parser,  String partStrategy ,
    		MessageAnnotator annotator, String erroTopic) {
    	this.parser = parser;
    	this.partStrategy = partStrategy;
    	this.annotator = annotator;
    	this.erroTopic = erroTopic;
    }
	@Override
	void doPost(ChannelHandlerContext ctx, FullHttpRequest msg, long arrivalTick) throws Exception {
		final long reciveTime = System.currentTimeMillis();
		final String anyKey = "send";/////////////////////
		final String kafkaKey = anyKey;
		//final byte[] rawMsg = Unpooled.buffer(msg.content().capacity()).writableBytes(msg.content()).array();/////////
		final byte[] rawMsg =null;
		final AnnotatedMessage annMsg;
		try {
			String sendId = "test_sender";
			byte[] testData = {
				0x00,0x01,0x01,0x01,0x01,0x01,0x01
			};
			annMsg = annotator.getAnnotatedMessage(sendId, testData, reciveTime);
		} catch (Exception e) {
			sendErrorData(kafkaKey, anyKey,rawMsg, reciveTime, ctx,
					new KafkaCallbackEvent(ctx.channel(),
					HttpUtil.isKeepAlive(msg),
					arrivalTick, 0));
			return;
		}
		final KafkaCallbackEvent kcevt = new KafkaCallbackEvent(ctx.channel(),
				HttpUtil.isKeepAlive(msg),
				arrivalTick, System.nanoTime());
		GenericObjectPool<Producer<String, byte[]>> kafkaPool = null;
		Producer<String , byte[]> producer = null;
		try {
			kafkaPool =
					ProtocolConverter.destinaltionDecider.getProducerPool(annMsg.getModel(), annMsg.getDestinaltion());
		    String kafkaTopic =
		    		ProtocolConverter.destinaltionDecider.getTopic(annMsg.getModel(), annMsg.getDestinaltion());
		    producer = kafkaPool.borrowObject();
		    producer.send(new ProducerRecord<>(kafkaTopic, kafkaKey, annMsg.toByte()),kcevt);

		} catch (Exception e) {
			e.printStackTrace();
			sendErrorData(kafkaKey, anyKey,rawMsg, reciveTime, ctx,
					new KafkaCallbackEvent(ctx.channel(),
					HttpUtil.isKeepAlive(msg),
					arrivalTick, 0));
			return;
		}
	}
    private void sendErrorData(String kafkaKey, String anyKey, byte[] rawMsg, long reciveTime,
    		ChannelHandlerContext ctx, KafkaCallbackEvent kcevt) throws Exception{
    	ErrorMessage errmsg = new ErrorMessage(anyKey, reciveTime, rawMsg);
    	Producer<String , byte[]> producer = null;
    	try {
    		producer = ProtocolConverter.errPool.borrowObject();
    		producer.send(new ProducerRecord<>(erroTopic, errmsg.toByte()), kcevt);
    	} catch(Exception e) {
    		sendResponse(ctx, HttpResponseStatus.SERVICE_UNAVAILABLE, kcevt.keepAlive,kcevt.arrivalTick);
    	} finally {
    		if (producer != null) {
    			ProtocolConverter.errPool.returnObject(producer);
    		}
    	}

    }
    static class KafkaCallbackEvent implements Callback{
    	final Channel channel;
    	final boolean keepAlive;
    	final long arrivalTick;
    	final long desparureTick;
    	Exception exc = null;
    	KafkaCallbackEvent(Channel channel, boolean keepAlive, long arrivalTick, long desparureTick){
    		this.channel = channel;
    		this.keepAlive = keepAlive;
    		this.arrivalTick = arrivalTick;
    		this.desparureTick = desparureTick;
    	}
		@Override
		public void onCompletion(RecordMetadata metadata, Exception exception) {
			//ProtocolConverter
			ChannelPipeline pipeline = this.channel.pipeline();
			if (exception != null) {
				this.exc = exception;
			}
			pipeline.fireUserEventTriggered(this);
		}

    }
}
