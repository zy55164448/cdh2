package fd.rawstore.function;

import java.time.Instant;

import fd.rawstore.bin.CanDataAnnotatedBean;
import scala.Tuple2;

public  abstract class FilterFunctionImpl extends FilterFunction{
	private static final long serialVersionUID = - 2022345678L;

	@Override
	public Tuple2<String, Tuple2<Instant, CanDataAnnotatedBean>> call(
			Tuple2<Instant, Tuple2<String, byte[]>> t)throws Exception {
		CanDataAnnotatedBean bean = getKeyInfo(t._2._2);
		Tuple2<Instant, CanDataAnnotatedBean> value = new
				Tuple2<Instant, CanDataAnnotatedBean>(t._1(),bean);
		return new Tuple2<String, Tuple2<Instant, CanDataAnnotatedBean>>(t._2()._1(),value);
	}

}
