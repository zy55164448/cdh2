package kafka.producer.message;

import java.util.HashMap;
import java.util.Map;

public class AnnotatedMessage implements Message{
	private final String annotateKey;
	private final long reciviveTime;
	private final byte[] message;
	private final Map<String, Object> annotateMap;

	public AnnotatedMessage(Map<String, Object> annotateMap, String annotateKey,
			long reciviveTime, byte[] message) throws Exception {

		if(!annotateMap.containsKey("vin")) {
			throw new Exception();
		}
		this.annotateKey = annotateKey;
		this.reciviveTime = reciviveTime;
		this.message = message;
		this.annotateMap = annotateMap;
	}

	@Override
	public byte[] toByte() {
		Map<String , Object> map = new HashMap(annotateMap);
		map.put("annotateKey", annotateKey);
		map.put("reciviveTime", reciviveTime);
		map.put("message", message);
		return MessageBuilder.build(map);
	}
	public String getVin() {
		return (String)annotateMap.get("vin");
	}

	public String getModel() {
		return (String)annotateMap.get("model");
	}
	public String getDestinaltion() {
		return (String)annotateMap.get("destination");
	}
	public String getAnnotateKey() {
		return annotateKey;
	}

	public long getReciviveTime() {
		return reciviveTime;
	}

	public byte[] getMessage() {
		return message;
	}

	public Map<String, Object> getAnnotateMap() {
		return annotateMap;
	}

}
