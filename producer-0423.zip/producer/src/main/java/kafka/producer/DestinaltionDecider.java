package kafka.producer;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.kafka.clients.producer.Producer;

import kafka.producer.datasource.DestinationDataSource;


public class DestinaltionDecider<K, V> {
	private Map<String, GenericObjectPool<Producer<K,V>>> producerPoolMap = new HashMap<>();
	private Map<String, Destinstion> destInfoMap = new HashMap<>();
	private ProducerPoolFactory<K,V> poolFactory;
	private final DestinationDataSource datasource;
	private int defaultKafkaClientMax;

	public DestinaltionDecider(DestinationDataSource datasource,
			int defaultKafkaClientMax,ProducerPoolFactory<K,V> poolFactory ) throws Exception{
		this.datasource = datasource;
		this.defaultKafkaClientMax = defaultKafkaClientMax;
		this.poolFactory = poolFactory;
		createProducerPool();
	}

	private void createProducerPool() throws Exception{
		Set<String> keys = datasource.keys();
		if (keys == null){
			throw new Exception("no keys");
		}
		for (String key :keys){
			createProducerPool(key);
		}
	}

	private void createProducerPool(String key) throws Exception{
		Map<String,String> destMap = datasource.query(key);
		if (destMap == null) {
			throw new Exception("no keys");
		} else if(!destMap.containsKey("servers") || !destMap.containsKey("topic")){
			throw new Exception("no keys");
		}
		createProducerPool(key,destMap.get("servers"), destMap.get("topic"));
		//destInfoMap.put(key, new Destinstion(servers, topic, 3));//
		if (producerPoolMap.containsKey("servers")){
			GenericObjectPool<Producer<K,V>> pool  = producerPoolMap.get("servers");
			return;
		}
		GenericObjectPool<Producer<K,V>> pool = poolFactory.create(servers,);
		producerPoolMap.put(servers, pool);
	}

	private void createProducerPool(String key, String servers, String topic) throws Exception{

		destInfoMap.put(key, new Destinstion(servers, topic, 3));//
		if (producerPoolMap.containsKey(servers)){
			GenericObjectPool<Producer<K,V>> pool  = producerPoolMap.get(servers);
			if (pool.getMaxTotal() > 0) {
				producerPoolMap.get(servers).setMaxTotal(3);
				producerPoolMap.get(servers).setMaxIdle(3);
			}
			return;
		}
		GenericObjectPool<Producer<K,V>> pool = poolFactory.create(servers,3, commonConfig);
		producerPoolMap.put(servers, pool);
	}

	public String getServers(String model, String dest)throws Exception{
		if(!destInfoMap.containsKey(model+ "_" + dest)){
			createProducerPool(model+ "_" + dest);
		}
		return destInfoMap.get(model+ "_" + dest).servers;
	}

	public String getTopic(String model, String dest)throws Exception{

		return destInfoMap.get(model+ "_" + dest).topic;
	}

	public Map<String, GenericObjectPool<Producer<K,V>>> createProducerPools(){
		return Collections.unmodifiableMap(new HashMap(producerPoolMap));
	}
}

