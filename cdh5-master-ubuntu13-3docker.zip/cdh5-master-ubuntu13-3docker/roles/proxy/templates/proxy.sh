export http_proxy={{ http_proxy}}
export https_proxy={{ https_proxy}}