package fd.rawstore.function;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZonedDateTime;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.VoidFunction;

import fd.rawstore.bin.CanDataAnnotatedBean;
import fd.rawstore.util.CtreateDirectory;
import scala.Tuple2;

public class SequenceWriteFunction
implements VoidFunction<JavaPairRDD<String, Tuple2<Instant,CanDataAnnotatedBean>>>{
	private static final long serialVersionUID = - 2022345678L;
	protected String rawStoreRootDir;
	protected String delimiter = "fffff";
	public void setRawStoreRootDir(String rawStoreRootDir) {
		this.rawStoreRootDir = rawStoreRootDir;
	}
	@Override
	public void call(JavaPairRDD<String, Tuple2<Instant,CanDataAnnotatedBean>> rdd) {
		JavaRDD<Tuple2<Instant,CanDataAnnotatedBean>> aa = rdd.values();

		JavaRDD<CanDataAnnotatedBean> rddCanDataAnnotatedBean = aa.map(new SetTimeFunction());
		write(rddCanDataAnnotatedBean);
	}

	protected  void write(JavaRDD<CanDataAnnotatedBean> rdd) {
		if(!rdd.isEmpty()) {
			ZonedDateTime now = ZonedDateTime.now();
			final String path =
					new Path(this.rawStoreRootDir,CtreateDirectory.createDirectoryPathFromTime(now))
					.toString();
			Configuration conf = new Configuration();
			conf.set("mapreduce.outpu.basename", String.valueOf(System.currentTimeMillis()));
			conf.set("mapreduce.output.fileoutputformat.compress", "true");
			conf.set("mapred.map.output.compress.codec", "org.apache.hadoop.io.compress.SnappyCodec");
			conf.set("mapred.map.output.compress.type", "BLOCK");
			rdd.mapToPair(new TranstormToSequenceFileFormat(this.delimiter.getBytes(StandardCharsets.UTF_8)))
			.saveAsNewAPIHadoopFile(path, NullWritable.class, BytesWritable.class,
					SequenceFileOutputFormat.class,conf);


		}
	}
}
