package function;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFlatMapFunction;
import org.apache.spark.api.java.function.VoidFunction;

import scala.Tuple2;

public class test_cy {

	public static void main(String[] args) {
		SparkConf conf=new SparkConf().setAppName("CanTimeReducer").setMaster("local[2]");
		JavaSparkContext sc = new JavaSparkContext(conf);
		//1506787111000 0x01 0x22 0x122 0x201
		TelegramHash telegramHash1 = new TelegramHash("1111",1506787111000L);
		CanUnitBean	canUnitBean11 = Unit.createCanUnitBean((short)0x01,"1506787111010");
		CanUnitBean	canUnitBean12 = Unit.createCanUnitBean((short)0x22,"1506787111020");
		CanUnitBean	canUnitBean13 = Unit.createCanUnitBean((short)0x122,"1506787111030");
		CanUnitBean	canUnitBean14 = Unit.createCanUnitBean((short)0x201,"1506787111050");

		CanUnitBean	canUnitBean11_1 = Unit.createCanUnitBean2((short)0x01,"1506787111110");
		CanUnitBean	canUnitBean12_1 = Unit.createCanUnitBean2((short)0x22,"1506787111120");
		CanUnitBean	canUnitBean13_1 = Unit.createCanUnitBean2((short)0x122,"1506787111130");
		CanUnitBean	canUnitBean14_1 = Unit.createCanUnitBean2((short)0x201,"1506787111150");

		CanUnitBean	canUnitBean11_null = Unit.createCanUnitBeanNull((short)0x01,"1506787111110");
		CanUnitBean	canUnitBean12_null  = Unit.createCanUnitBeanNull((short)0x22,"1506787111120");
		CanUnitBean	canUnitBean13_null = Unit.createCanUnitBeanNull((short)0x122,"1506787111130");
		CanUnitBean	canUnitBean14_null = Unit.createCanUnitBeanNull((short)0x201,"1506787111150");

		//1506787222000 0x01 0x22 0x122 0x201
		TelegramHash telegramHash2 = new TelegramHash("2222",1506787111000L);
		CanUnitBean	canUnitBean21 = Unit.createCanUnitBean((short)0x01,"1506787222010");
		CanUnitBean	canUnitBean22 = Unit.createCanUnitBean((short)0x22,"1506787222020");
		CanUnitBean	canUnitBean23 = Unit.createCanUnitBean((short)0x122,"1506787222030");
		CanUnitBean	canUnitBean24 = Unit.createCanUnitBean((short)0x201,"1506787222040");

		CanUnitBean	canUnitBean21_1 = Unit.createCanUnitBean2((short)0x01,"1506787222110");
		CanUnitBean	canUnitBean22_1 = Unit.createCanUnitBean2((short)0x22,"1506787222120");
		CanUnitBean	canUnitBean23_1 = Unit.createCanUnitBean2((short)0x122,"1506787222130");
		CanUnitBean	canUnitBean24_1 = Unit.createCanUnitBean2((short)0x201,"1506787222140");
		CanUnitBean	canUnitBean21_null = Unit.createCanUnitBeanNull((short)0x01,"1506787222210");
		CanUnitBean	canUnitBean22_null = Unit.createCanUnitBeanNull((short)0x22,"1506787222220");
		CanUnitBean	canUnitBean23_null = Unit.createCanUnitBeanNull((short)0x122,"1506787222230");
		CanUnitBean	canUnitBean24_null = Unit.createCanUnitBeanNull((short)0x201,"1506787222240");

		JavaRDD<Tuple2<TelegramHash, CanUnitBean>> rdd = sc.parallelize(Arrays.asList(
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash1,canUnitBean11),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash1,canUnitBean12),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash1,canUnitBean13),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash1,canUnitBean14),

				new Tuple2<TelegramHash, CanUnitBean>(telegramHash1,canUnitBean11_1),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash1,canUnitBean12_1),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash1,canUnitBean13_1),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash1,canUnitBean14_1),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash1,canUnitBean11_null),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash1,canUnitBean12_null),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash1,canUnitBean13_null),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash1,canUnitBean14_null),

				new Tuple2<TelegramHash, CanUnitBean>(telegramHash2,canUnitBean21),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash2,canUnitBean22),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash2,canUnitBean23),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash2,canUnitBean24),

				new Tuple2<TelegramHash, CanUnitBean>(telegramHash2,canUnitBean21_1),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash2,canUnitBean22_1),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash2,canUnitBean23_1),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash2,canUnitBean24_1),

				new Tuple2<TelegramHash, CanUnitBean>(telegramHash2,canUnitBean21_null),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash2,canUnitBean22_null),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash2,canUnitBean23_null),
				new Tuple2<TelegramHash, CanUnitBean>(telegramHash2,canUnitBean24_null)
				),2);

		JavaPairRDD<TelegramHash, CanUnitBean> pairRDD = JavaPairRDD.fromJavaRDD(rdd);

		JavaPairRDD<TelegramHash, CanUnitBean> pairRDDReducer =
				pairRDD.mapPartitionsToPair(new PairFlatMapFunction<Iterator<Tuple2<TelegramHash, CanUnitBean>>,TelegramHash, CanUnitBean>(){

					@Override
					public Iterable<Tuple2<TelegramHash, CanUnitBean>> call(
							Iterator<Tuple2<TelegramHash, CanUnitBean>> its) throws Exception {


						//VIN =>  Map<<CanID 最终结果>>
						HashMap<String, TreeMap<Integer, CanUnitBean>> Telegram = new HashMap<String, TreeMap<Integer, CanUnitBean>>();
						//VIN => ReliveTime MAP
						HashMap<String, Long> Timestamp = new HashMap<String, Long>();

						while (its.hasNext()) {
							Tuple2<TelegramHash, CanUnitBean> next = its.next();

							//VIN=>存放最终结果的Map<canId, Bean>
							TreeMap<Integer, CanUnitBean> rvTelegram = Telegram.get(next._1.deviceId);

							if(rvTelegram == null) {
								Timestamp.put(next._1.deviceId, next._1.timestamp);

								rvTelegram =new TreeMap<Integer, CanUnitBean>();
								Telegram.put(next._1.deviceId, rvTelegram);
							}

							Short CanId = next._2.getCanId();
							//以100毫秒取整,000,100,200,etc
							short tmStamp = (short)(next._2.getCanTime()%1000);
							tmStamp = (short) (tmStamp - tmStamp%100);
							//高16位百毫秒 + 低16位CanID 标识每百毫秒切片的结果
							Integer keyBean = (tmStamp << 16 | CanId);
							CanUnitBean rvCanUnitBean = rvTelegram.get(keyBean);

							if(rvCanUnitBean == null) {
								rvCanUnitBean = new CanUnitBean(next._2);//新规深复制函数

								rvTelegram.put(keyBean, rvCanUnitBean);

								rvCanUnitBean.setCanTime(tmStamp);
							}else{//百毫秒未改变
								//处理假定 某个VIN/CanId标识的所有报文的Label数目相同
								Map<String ,Object> rvMap = (Map<String,Object>)rvCanUnitBean.getConvertedDataMap();
								for (Map.Entry<String, Object> entry  : rvMap.entrySet()) {

									//当前时戳下值为空，pass
									Object refreshValue = next._2.getConvertedDataMap().get(entry.getKey());
									if(refreshValue == null)
										continue;

									rvMap.replace(entry.getKey(),refreshValue);
								}
							}
						}

						//遍历VIN
						ArrayList<Tuple2<TelegramHash, CanUnitBean>> tuble2s = new ArrayList<>();
		                for (Map.Entry<String, TreeMap<Integer, CanUnitBean>>telEntry : Telegram.entrySet()) {
		                	TelegramHash tel = new TelegramHash(telEntry.getKey(), Timestamp.get(telEntry.getKey()));

		                	//CanId List 作成,利用TreeSet去除重复和排序
		                	Set<Short> CanIdSet = new TreeSet<Short>();
		                	for(Integer key : telEntry.getValue().keySet())
		                		CanIdSet.add(((short)(key&0xffff)));

		                	tel.CanId.addAll(CanIdSet);

		                	//100毫秒内同CanId下结果CanUnitBean作成，No1,No2,No3,No1,NO2,No3,No4,No1,No2......

		                	CanUnitBean rvCanBean = new CanUnitBean();

		                	Integer mm100 = 0;
		                	Map<String, Object> dest = new HashMap<String, Object>();
		                	rvCanBean.addResult(dest, mm100);
		                	for(Map.Entry<Integer,CanUnitBean> pre1000 : telEntry.getValue().entrySet()) {

		                		//不同100毫秒片断，新建Map<String, Object>存放
		                		if(((pre1000.getKey() & 0xffff0000)>>16) != mm100) {
		                			mm100 = (pre1000.getKey() & 0xffff0000) >>16;
				                	dest = new HashMap<String, Object>();
				                	rvCanBean.addResult(dest, mm100);
		                		}

		                		//同100毫秒内，不同CanId合并
		                		Map<String, Object> src = (Map<String, Object>)pre1000.getValue().getConvertedDataMap();//source
		                		for(Map.Entry<String, Object> dataEntry  :src.entrySet()){
		                			dest.put(dataEntry.getKey(), dataEntry.getValue());
		                		}
		                	}
		                	tuble2s.add(new Tuple2<TelegramHash, CanUnitBean>(tel,rvCanBean));
		                }
						return tuble2s;
					}
				}
				);


		pairRDDReducer.foreach(new VoidFunction<Tuple2<TelegramHash, CanUnitBean>>() {
            @Override
            public void call(Tuple2<TelegramHash, CanUnitBean> tp2) throws Exception {
                System.out.println(tp2._1.deviceId + "->" + tp2._2.getCanId() + "\n");

                for(int i =0; i < tp2._2.getMmResult().size(); ++i)
                    System.out.println("\t->mm:" + tp2._2.getMmResult().get(i).toString()+ "->"+ tp2._2.getResult().get(i).toString()+"\n");
            }
        });


	}

	private static CanUnitBean createCanUnitBean(short id ,String canTime) {
		CanUnitBean bean = new CanUnitBean();
		bean.setCanId(id);
		bean.setCanTime(Long.parseLong(canTime));
		Map<String,Object> values = new HashMap<>();

		switch(id) {
			case 0x01:
			  values.put("c001_dummy15", 1L);
			  values.put("c001_dummy16", 2L);
			  values.put("c001_dummy17", 3L);
			  break;
			case 0x22:
			  values.put("c022_dummy15", 1L);
			  values.put("c022_dummy16", 2L);
			  values.put("c022_dummy17", 3L);
			  values.put("c022_dummy17", 4L);
			  break;
			case 0x122:
			  values.put("c122_dummy15", 1L);
			  values.put("c122_dummy16", 2L);
			  values.put("c122_dummy17", 3L);
			  values.put("c122_dummy17", 4L);
			  values.put("c122_dummy17", 5L);
			  break;
			case 0x201:
			  values.put("c201_dummy15", 1L);
			  values.put("c201_dummy16", 2L);
			  values.put("c201_dummy17", 3L);
			  values.put("c201_dummy17", 4L);
			  values.put("c201_dummy17", 5L);
			  values.put("c201_dummy17", 6L);
			  break;
		}
		bean.setConvertedDataMap(values);
		return bean;
	}
}
