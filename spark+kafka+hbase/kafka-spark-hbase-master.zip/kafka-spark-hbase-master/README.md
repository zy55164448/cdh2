/opt/cloudera/parcels/CDH/lib/spark/bin/spark-submit --class com.epam.bigdata.spark2.SparkStreamer --master yarn  ./kafka-spark-hbase-1.0-SNAPSHOT-jar-with-dependencies.jar localhost:2181 logs default 1 logs log 

