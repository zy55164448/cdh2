package kafka.producer.message;

import java.nio.ByteBuffer;

import io.netty.buffer.ByteBuf;

public class MessageParser {
    private int keyIndex;
    private int keyLength;
    public MessageParser(int keyIndex, int keyLength) {
    	this.keyIndex = keyIndex;
    	this.keyLength = keyLength;
    }
    public String getAnnotateKey(ByteBuf msg) {
    	ByteBuffer annotateKey = ByteBuffer.allocate(Long.BYTES);
    	annotateKey.position(Long.BYTES- keyLength);
    	annotateKey.put(msg.nioBuffer(keyIndex, keyLength));
    	return Long.toString(annotateKey.getLong(0));
    }
}
