package kafka.producer.message;

public interface Message {
    public byte[] toByte();
}
