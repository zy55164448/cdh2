package kafka.producer;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;

public class PooledProducerFactory<K,V> extends BasePooledObjectFactory<Producer<K,V>>{
	private AtomicInteger idissuer = new AtomicInteger(1);
	private Properties properties;
	private WeakHashMap<Producer<K,V>, String> producers;
	private String name;

	public PooledProducerFactory(Properties properties, String name) {
		this.properties = properties;
		this.name = name;
		producers = new WeakHashMap<>();
	}
	public Map<Producer<K,V>, String> createProducers(){
		return Collections.unmodifiableMap(new HashMap<>(producers));
	}
	@Override
	public Producer<K, V> create() throws Exception {
		String clientId = String.format("kafka-producer-%d_%s",idissuer, name);
		Properties instanceProperties = new Properties();
		properties.stringPropertyNames().forEach(name -> {
			instanceProperties.setProperty(name, properties.getProperty(name));
		});

		instanceProperties.setProperty(ProducerConfig.CLIENT_ID_CONFIG, clientId);
		KafkaProducer<K,V> producer = new KafkaProducer<>(instanceProperties);

		producers.put(producer, clientId);
		return producer;
	}
	 @Override
	    public void destroyObject(PooledObject<Producer<K,V>> p)
	        throws Exception  {
		 p.getObject().close();
	    }
	@Override
	public PooledObject<Producer<K, V>> wrap(Producer<K, V> obj) {

		return new DefaultPooledObject<>(obj);
	}

}
