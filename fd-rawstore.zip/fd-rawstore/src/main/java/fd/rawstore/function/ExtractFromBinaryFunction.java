package fd.rawstore.function;

import java.io.IOException;
import java.time.Instant;

import org.apache.spark.api.java.function.PairFunction;

import fd.rawstore.bin.CanDataAnnotatedBean;
import scala.Tuple2;

public  abstract class ExtractFromBinaryFunction implements
  PairFunction<Tuple2<Instant,Tuple2<String,byte[]>>,String,Tuple2<Instant,CanDataAnnotatedBean>>{
	private static final long serialVersionUID = - 2022345678L;

	@Override
	public Tuple2<String, Tuple2<Instant, CanDataAnnotatedBean>> call(
			Tuple2<Instant, Tuple2<String, byte[]>> t)throws Exception {
		CanDataAnnotatedBean bean = getKeyInfo(t._2._2);
		Tuple2<Instant, CanDataAnnotatedBean> value = new
				Tuple2<Instant, CanDataAnnotatedBean>(t._1(),bean);
		return new Tuple2<String, Tuple2<Instant, CanDataAnnotatedBean>>(t._2()._1(),value);
	}

    protected abstract CanDataAnnotatedBean getKeyInfo(byte[] body) throws IOException;
}
