package function2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.apache.spark.api.java.function.PairFlatMapFunction;

import scala.Tuple2;

public class PairTimeIntervalAggregationFunction implements
PairFlatMapFunction<Iterator<Tuple2<TelegramHash, CanUnitBean>>,TelegramHash, CanUnitBean>{
	private static final long serialVersionUID = - 2022345678L;
	private final int timeInterval;

	public PairTimeIntervalAggregationFunction (int timeInterval) {
		this.timeInterval = timeInterval;
	}
	@Override
	public Iterable<Tuple2<TelegramHash, CanUnitBean>> call(
			Iterator<Tuple2<TelegramHash, CanUnitBean>> its) throws Exception {

		//VIN =>  Map<<CanID 最终结果>>
		HashMap<String, TreeMap<Integer, CanUnitBean>> Telegram = new HashMap<String, TreeMap<Integer, CanUnitBean>>();
		//VIN => ReliveTime MAP
		HashMap<String, Long> Timestamp = new HashMap<String, Long>();
		while (its.hasNext()) {
			Tuple2<TelegramHash, CanUnitBean> next = its.next();
			//以100毫秒取整,000,100,200,etc
			int tmStamp = (int)(next._2.getCanTime()%1000);
			tmStamp = (short) (tmStamp - tmStamp%timeInterval);
			//VIN=>存放最终结果的Map<canId, Bean>
			TreeMap<Integer, CanUnitBean> rvTelegram = Telegram.get(next._1.deviceId);

			if(rvTelegram == null) {
				Timestamp.put(next._1.deviceId, next._1.timestamp);

				rvTelegram =new TreeMap<Integer, CanUnitBean>();
				Telegram.put(next._1.deviceId, rvTelegram);
			}

			Short CanId = next._2.getCanId();

			//高16位百毫秒 + 低16位CanID 标识每百毫秒切片的结果
			Integer keyBean = (tmStamp << 16 | CanId);
			CanUnitBean rvCanUnitBean = rvTelegram.get(keyBean);

			if(rvCanUnitBean == null) {
				rvCanUnitBean = new CanUnitBean(next._2);//新规深复制函数

				rvTelegram.put(keyBean, rvCanUnitBean);

				rvCanUnitBean.setCanTime(tmStamp);
			}else{//百毫秒未改变
				//处理假定 某个VIN/CanId标识的所有报文的Label数目相同
				Map<String ,Object> rvMap = (Map<String,Object>)rvCanUnitBean.getConvertedDataMap();
				for (Map.Entry<String, Object> entry  : rvMap.entrySet()) {

					//当前时戳下值为空，pass
					Object refreshValue = next._2.getConvertedDataMap().get(entry.getKey());
					if(refreshValue == null)
						continue;

					rvMap.replace(entry.getKey(),refreshValue);
				}
			}
		}

		//遍历VIN
		ArrayList<Tuple2<TelegramHash, CanUnitBean>> tuble2s = new ArrayList<>();
        for (Map.Entry<String, TreeMap<Integer, CanUnitBean>>telEntry : Telegram.entrySet()) {
        	TelegramHash tel = new TelegramHash(telEntry.getKey(), Timestamp.get(telEntry.getKey()));

        	//100毫秒内同CanId下结果CanUnitBean连接为list
        	CanUnitBean listBean = null;
        	Integer mm100 = -1;
        	for(Map.Entry<Integer,CanUnitBean> pre1000 : telEntry.getValue().entrySet()) {

        		if(((pre1000.getKey() & 0xffff0000)>>16) != mm100) {
        			mm100 = (pre1000.getKey() & 0xffff0000)>>16;
        			listBean = pre1000.getValue();
                	tuble2s.add(new Tuple2<TelegramHash, CanUnitBean>(tel,listBean));
        		}else {
        			listBean.addNext(pre1000.getValue());//添加到链尾
        			listBean = pre1000.getValue();//指向链尾
        		}
        	}
        }
		return tuble2s;
	}
}
