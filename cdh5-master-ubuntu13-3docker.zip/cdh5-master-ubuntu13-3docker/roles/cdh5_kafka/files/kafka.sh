export PATH=/opt/kafka/bin:$PATH
