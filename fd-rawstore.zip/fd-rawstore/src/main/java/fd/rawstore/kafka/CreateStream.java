package fd.rawstore.kafka;

public class CreateStream {

}
