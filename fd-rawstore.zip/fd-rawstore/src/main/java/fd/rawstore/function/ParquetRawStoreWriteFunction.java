package fd.rawstore.function;

import java.time.Instant;
import java.time.ZonedDateTime;

import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.DataFrameWriter;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;

import fd.rawstore.bin.CanDataAnnotatedBean;
import fd.rawstore.util.CtreateDirectory;
import scala.Tuple2;

public class ParquetRawStoreWriteFunction
 implements VoidFunction<JavaPairRDD<String, Tuple2<Instant,CanDataAnnotatedBean>>>{
	private static final long serialVersionUID = - 2022345678L;
	protected String rawStoreRootDir;
	protected String delimiter;
	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}
	public void setRawStoreRootDir(String rawStoreRootDir) {
		this.rawStoreRootDir = rawStoreRootDir;
	}
	@Override
	public void call(JavaPairRDD<String, Tuple2<Instant,CanDataAnnotatedBean>> rdd) {
		write(rdd.values().map(new SetCreateTimeFunction()));
	}

	protected  void write(JavaRDD<CanDataAnnotatedBean> rdd) {
		if(!rdd.isEmpty()) {
			ZonedDateTime now = ZonedDateTime.now();
			final String path =
					new Path(this.rawStoreRootDir,CtreateDirectory.createDirectoryPathFromTime(now))
					.toString();
			SparkSession sparkSession =SparkSession.builder().getOrCreate();
			Dataset<Row> ds = sparkSession.createDataFrame(rdd, CanDataAnnotatedBean.class);
			DataFrameWriter<Row> writer = ds.write();
			writer.mode(SaveMode.Append).parquet(path);
		}
	}
}
