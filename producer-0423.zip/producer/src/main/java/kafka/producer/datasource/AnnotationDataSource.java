package kafka.producer.datasource;

import java.util.Map;

public interface AnnotationDataSource {
    Map<String, Object> query(String senderId);
}
