cd /home/cdh5-master-0710-1node/
ansible-playbook playbooks/operation/start_hbase.yml -i hosts
