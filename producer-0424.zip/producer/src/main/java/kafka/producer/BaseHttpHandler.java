package kafka.producer;

import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaderValues;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpUtil;
import io.netty.handler.codec.http.HttpVersion;


public abstract class BaseHttpHandler extends SimpleChannelInboundHandler<FullHttpRequest>{
	private static final HttpVersion HTTPVERSION = HttpVersion.HTTP_1_1;
	@Override
    public void channelRead0(ChannelHandlerContext ctx, FullHttpRequest msg) throws Exception{
		final long arrivaTick = System.nanoTime();
		if (msg ==null) {
			sendResponse(ctx, HttpResponseStatus.BAD_REQUEST, false);
			return;
		}
		if (msg.decoderResult().isFailure()) {
			sendResponse(ctx, HttpResponseStatus.BAD_REQUEST, false);
			return;
		}
		if(HttpMethod.POST.equals(msg.method())) {
			//ProtocolConverter
			doPost(ctx, msg,arrivaTick);
		} else if (HttpMethod.GET.equals(msg.method())){
			doGet(ctx,msg);
		} else {
			sendResponse(ctx, HttpResponseStatus.METHOD_NOT_ALLOWED, HttpUtil.isKeepAlive(msg));
		}
	}

	void doGet(ChannelHandlerContext ctx, FullHttpRequest msg)
			throws Exception{
		sendResponse(ctx, HttpResponseStatus.OK, HttpUtil.isKeepAlive(msg));
	}

	abstract void doPost(ChannelHandlerContext ctx, FullHttpRequest msg, final long arrivalTick )
			throws Exception;

	static void sendResponse(ChannelHandlerContext ctx, HttpResponseStatus status,boolean keepActive) {
		sendResponse(ctx, status, keepActive,0);
	}
	static void sendResponse(ChannelHandlerContext ctx, HttpResponseStatus status,boolean keepActive,
			long arrivalTick) {
		FullHttpResponse response = new DefaultFullHttpResponse(HTTPVERSION, status);
		ChannelFutureListener listener = (future) ->{
			///////////
			long tat = System.nanoTime() - arrivalTick;
			//updateRecvTat(tat);
		};
		if(keepActive) {
			response.headers().setInt(HttpHeaderNames.CONTENT_LENGTH, response.content().readableBytes());
			response.headers().set(HttpHeaderNames.CONNECTION, HttpHeaderValues.KEEP_ALIVE);
			ChannelFuture cf = ctx.writeAndFlush(response);
			if(arrivalTick > 0) {
				cf.addListener(listener);
			}
		}else {
			ChannelFuture cf = ctx.writeAndFlush(response);
			if(arrivalTick > 0) {
				cf.addListener(listener);
			}
			cf.addListener(ChannelFutureListener.CLOSE);
		}
	}
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
            throws Exception {
        ctx.close();
    }
}
