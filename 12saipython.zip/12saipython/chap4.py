num = 1
if num == 1:
    print("numは 1 です")
else:
    print("numは 1 ではありません")
print("おわり")