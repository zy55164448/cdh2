package fd.rawstore;

import java.time.Instant;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.function.Function0;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import fd.rawstore.bin.CanDataAnnotatedBean;
import fd.rawstore.function.ParquetRawStoreWriteFunction;
import fd.rawstore.function.SetCreateTimeFunction;
import fd.rawstore.kafka.CreateStreamImpl;
import scala.Tuple2;

public class JavaStreamingContextCreater implements Function0<JavaStreamingContext>{
	private static final long serialVersionUID = - 2022345678L;
	@Override
	public JavaStreamingContext call() throws Exception {
		final long batchInterval = 60000L;
		JavaStreamingContext ssc = new JavaStreamingContext(new SparkConf(), Durations.milliseconds(batchInterval));
		ssc.checkpoint("/tmp/checkpoint");
		CreateStreamImpl createStreamImpl = new CreateStreamImpl();

		CreateStreamImpl creater = new CreateStreamImpl();
		JavaPairDStream<String, Tuple2<Instant, CanDataAnnotatedBean>> blos =
				creater.createStream().map(new SetCreateTimeFunction<Tuple2<String,byte[]>>())
				.repartition(10);
		ParquetRawStoreWriteFunction parquetRawStoreWriteFunction = new ParquetRawStoreWriteFunction();
		blos.foreachRDD(parquetRawStoreWriteFunction);

		return null;
	}

}
