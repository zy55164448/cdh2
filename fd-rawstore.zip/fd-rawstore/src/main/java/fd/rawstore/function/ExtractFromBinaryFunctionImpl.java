package fd.rawstore.function;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;

import fd.rawstore.bin.CanDataAnnotatedBean;

public  abstract class ExtractFromBinaryFunctionImpl extends ExtractFromBinaryFunction{
	private static final long serialVersionUID = - 2022345678L;


	@Override
    protected CanDataAnnotatedBean getKeyInfo(byte[] body) throws IOException{
		ObjectMapper mapper = new ObjectMapper(new MessagePackFactory());
	}
}
