MQTT Kafka Bridge
=================
A Spring Boot based Bridge Between MQTT and Kafka.

To Package
----------

1. mvn clean install
2. Use the .jar file and libs folder created in the target directory

To Run
------

1. mvn spring-boot:run
