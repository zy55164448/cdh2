package kafka.producer.datasource;

import java.io.Closeable;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisCommands;
import redis.clients.jedis.JedisPool;

public class RedisConnectionFactory {
	public static RedisConnection createConnetion(String redisAdress) {
		String[] redisNodeAdress  = redisAdress.split(",");
		if(redisNodeAdress.length > 1) {
			Set<HostAndPort> nodes = new HashSet<>();
			for(String adress : redisNodeAdress) {
				String[] hostPortArray = adress.split(":");
				nodes.add(new HostAndPort(hostPortArray[0], Integer.parseInt(hostPortArray[1])));
			}
			return new RedisClusterConnection(nodes);
		} else {
			String[] hostPortArray = redisNodeAdress[0].split(":");
			return new RedisPoolrConnection(hostPortArray[0], Integer.parseInt(hostPortArray[1]));
		}
	}

	protected interface RedisConnection extends Closeable {
		JedisCommands getInstance();
		void returnInstance(JedisCommands instance);
		@Override
		void close();
	}


	private static class RedisClusterConnection implements RedisConnection {
		private JedisCluster jedisCluster;
        public RedisClusterConnection(Set<HostAndPort> nodes) {
        	this.jedisCluster = new JedisCluster(nodes);
        }
		@Override
		public JedisCommands getInstance() {
			// TODO 自動生成されたメソッド・スタブ
			return jedisCluster;
		}

		@Override
		public void returnInstance(JedisCommands instance) {
			// TODO 自動生成されたメソッド・スタブ

		}

		@Override
		public void close() {
			try {
				jedisCluster.close();
			} catch(IOException e) {
			}

		}

	}

	public static class RedisPoolrConnection implements RedisConnection {
		private JedisPool jedisPool;
        public RedisPoolrConnection(String host, int port) {
        	this.jedisPool = new JedisPool(host, port);
        }
		@Override
		public JedisCommands getInstance() {
			// TODO 自動生成されたメソッド・スタブ
			return jedisPool.getResource();
		}

		@Override
		public void returnInstance(JedisCommands instance) {
			if(instance == null) {
				return;
			}else {
				try {
					((Closeable)instance).close();
				} catch(IOException e) {
				}
			}
		}

		@Override
		public void close() {
			jedisPool.close();
		}

	}
}
