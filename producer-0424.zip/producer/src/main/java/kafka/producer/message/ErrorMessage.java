package kafka.producer.message;

import java.util.HashMap;
import java.util.Map;

public class ErrorMessage implements Message{
	private final String annotateKey;
	private final long reciviveTime;
	private final byte[] message;


	public ErrorMessage( String annotateKey,
			long reciviveTime, byte[] message){

		this.annotateKey = annotateKey;
		this.reciviveTime = reciviveTime;
		this.message = message;
	}

	@Override
	public byte[] toByte() {
		Map<String , Object> map = new HashMap<>();
		map.put("annotateKey", annotateKey);
		map.put("reciviveTime", reciviveTime);
		map.put("message", message);
		return MessageBuilder.build(map);
	}


	public String getAnnotateKey() {
		return annotateKey;
	}

	public long getReciviveTime() {
		return reciviveTime;
	}

	public byte[] getMessage() {
		return message;
	}


}
