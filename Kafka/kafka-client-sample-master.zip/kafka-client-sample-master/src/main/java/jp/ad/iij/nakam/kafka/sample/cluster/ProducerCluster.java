package jp.ad.iij.nakam.kafka.sample.cluster;

import java.util.Date;
import java.util.Properties;
import java.util.Random;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

public class ProducerCluster {

    private long nEvents;
    protected Producer<String, String> producer;

    public static void main(String[] args) {
        ProducerCluster ps = new ProducerCluster(10);
        ps.start();
    }

    public ProducerCluster(long nEvents) {
        this.nEvents = nEvents;
        configure();
    }

    public void configure() {
        Properties props = new Properties();
        props.put("serializer.class", "kafka.serializer.StringEncoder");
        props.setProperty("metadata.broker.list", "localhost:9092");
        ProducerConfig config = new ProducerConfig(props);
        producer = new Producer<String, String>(config);
    }

    public void start() {
        Random rnd = new Random();
        for (long event = 0; event < nEvents; event++) {
            String ip = ". 192.168.2." + rnd.nextInt(255);
            String msg = "task no " + (event + 1) + ip;
            KeyedMessage<String, String> data = new KeyedMessage<String, String>("page_visits", ip, msg);
            System.out.println(new Date() + " : task no " + (event + 1) + ". send from producer");
            producer.send(data);
        }
    }
}
