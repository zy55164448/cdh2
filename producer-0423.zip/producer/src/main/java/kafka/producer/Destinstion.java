
package kafka.producer;

public class Destinstion {
	public final String servers;
	public final String topic;
	public final int kafkaClinetMax;

	public Destinstion(String servers, String topic, int kafkaClinetMax) {
		this.servers = servers;
		this.topic = topic;
		this.kafkaClinetMax = kafkaClinetMax;
	}

}
