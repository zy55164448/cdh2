package fd.rawstore.function;

import java.time.Instant;

import org.apache.spark.api.java.function.Function;

import scala.Tuple2;

public class SetTimeFunction<T> implements Function<T, Tuple2<Instant,T>>{
	private static final long serialVersionUID = - 2022345678L;
	public Tuple2<Instant, T> call(T v1) throws Exception {
		Instant startTime = Instant.now();
		return new Tuple2<Instant, T>(startTime, v1);
	}

}
