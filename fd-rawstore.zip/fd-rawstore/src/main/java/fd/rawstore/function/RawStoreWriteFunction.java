package fd.rawstore.function;

import java.time.Instant;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.VoidFunction;

import fd.rawstore.bin.CanDataAnnotatedBean;
import scala.Tuple2;

public abstract class RawStoreWriteFunction
 implements VoidFunction<JavaPairRDD<String, Tuple2<Instant,CanDataAnnotatedBean>>>{
	private static final long serialVersionUID = - 2022345678L;
	protected String rawStoreRootDir;
	protected String delimiter;
	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}
	public void setRawStoreRootDir(String rawStoreRootDir) {
		this.rawStoreRootDir = rawStoreRootDir;
	}
	@Override
	public void call(JavaPairRDD<String, Tuple2<Instant,CanDataAnnotatedBean>> rdd) {
		write(rdd.values().map(new SetCreateTimeFunction()));
	}

	protected abstract void write(JavaRDD<CanDataAnnotatedBean> rdd);
}
