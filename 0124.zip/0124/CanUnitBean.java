package function;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.KryoSerializable;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

public class CanUnitBean implements Serializable , KryoSerializable{

	private static final long serialVersionUID = - 2022345678L;

	private short canId;
	private long canTime;
	private Map<String ,?> convertedDataMap;
	private List<Map<String, ?>> result = new ArrayList<Map<String, ?>>();
	private List<Integer> mm100 =   new ArrayList<Integer>();
	public CanUnitBean() {

	}

	public  CanUnitBean(CanUnitBean clone) {
		this.canId = clone.canId;
		this.canTime = clone.canTime;
		this.convertedDataMap = new HashMap<>(clone.convertedDataMap);
	}
	@Override
	public void read(Kryo arg0, Input arg1) {
		// TODO 自動生成されたメソッド・スタブ

	}

	@Override
	public void write(Kryo arg0, Output arg1) {
		// TODO 自動生成されたメソッド・スタブ

	}

	public short getCanId() {
		return canId;
	}

	public void setCanId(short canId) {
		this.canId = canId;
	}

	public long getCanTime() {
		return canTime;
	}

	public void setCanTime(long canTime) {
		this.canTime = canTime;
	}

	public Map<String ,?> getConvertedDataMap() {
		return convertedDataMap;
	}

	public void setConvertedDataMap(Map<String ,?> convertedDataMap) {
		this.convertedDataMap = convertedDataMap;
	}

	public void addResult(Map<String, ?> preResult, Integer mm) {
		result.add(preResult);
		mm100.add(mm);
	}

	public List<Map<String, ?>> getResult() {
		return result;
	}
	public List<Integer> getMmResult() {
		return mm100;
	}
}
