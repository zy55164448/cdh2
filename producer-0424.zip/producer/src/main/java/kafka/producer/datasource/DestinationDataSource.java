package kafka.producer.datasource;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

import kafka.producer.datasource.RedisConnectionFactory.RedisConnection;
import redis.clients.jedis.JedisCommands;

public class DestinationDataSource {
    private RedisConnection redis;

    public DestinationDataSource(String redisAdress) {
    	redis = RedisConnectionFactory.createConnetion(redisAdress);
    }
    public Map<String , String> query(String key){
    	JedisCommands jedisCommands = redis.getInstance();
    	try {
    		Map<String, String> values = jedisCommands.hgetAll(key);
    		if (values == null || values.isEmpty()) {
    			return null;
    		}
    		return Collections.<String, String>unmodifiableMap(values);
    	} finally {
    		redis.returnInstance(jedisCommands);
    	}
    }
    public Set<String> keys(){
    	JedisCommands jedisCommands = redis.getInstance();
    	try {
    		Set<String> values = jedisCommands.smembers("destination_keys");
    		if (values == null || values.isEmpty()) {
    			return null;
    		}
    		return Collections.<String>unmodifiableSet(values);
    	} finally {
    		redis.returnInstance(jedisCommands);
    	}
    }
}
