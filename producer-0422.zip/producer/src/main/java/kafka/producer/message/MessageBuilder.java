package kafka.producer.message;

import java.io.IOException;

import org.msgpack.MessagePack;
import org.msgpack.packer.BufferPacker;

public class MessageBuilder {
	public static byte[] build(Object message) {
		try {
			final BufferPacker packer = new MessagePack().createBufferPacker();
			packer.write(message);
			final byte[] annBotyTomsgPack = packer.toByteArray();/////////////
			packer.clear();
			return annBotyTomsgPack;
		}catch(IOException e) {
		}
			throw new RuntimeException();
	}
}
