package kafka.producer;

import java.util.Properties;

import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;

public class ProducerPoolFactory<K, V> {
	public GenericObjectPool<Producer<K,V>> create(String servers, int kafkaClinetMax
			, Properties prop){
		PooledProducerFactory<K,V> ppf = new PooledProducerFactory(
				createProperties(servers,prop), servers.split(":")[0]);
		GenericObjectPool<Producer<K,V>> pool  = new GenericObjectPool<>(ppf);
		pool.setMaxTotal(3);
		pool.setMaxIdle(3);

		return pool;
	}
	private Properties createProperties (String servers, Properties commonProp) {
		Properties prop = new Properties();
		commonProp.stringPropertyNames().forEach(name -> {
			prop.setProperty(name, commonProp.getProperty(name));
		});
		prop.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, servers);
		return prop;
	}
}
