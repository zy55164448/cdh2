package jp.ad.iij.nakam.kafka.sample.cluster;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import kafka.consumer.ConsumerConfig;
import kafka.consumer.ConsumerIterator;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;

public class ConsumerCluster {
    int consumerNum;
    private static final int TEST_TIMES = 100;
    static int count;
    private final ConsumerConnector connector;
    private ExecutorService executor;
    private static ConsumerCluster consumer = null;

    private String zooKeeper = "localhost:2181";
    private String topic = "page_visits";

    public static void main(String[] args) {
        count = new Integer(TEST_TIMES);
        int consumerSize = 5;
        // consumerの追加
        for (int i = 1; i <= consumerSize; i++) {
            consumer = new ConsumerCluster(i, "group1");
            consumer.run(1);
            consumer = new ConsumerCluster(i, "group2");
            consumer.run(1);
        }

        // producerの実行
        ProducerCluster producer = new ProducerCluster(TEST_TIMES);
        producer.configure();
        producer.start();

    }

    public ConsumerCluster(int num, String groupId) {
        consumerNum = num;
        connector = kafka.consumer.Consumer.createJavaConsumerConnector(createConsumerConfig(zooKeeper, groupId));
    }

    public void shutdown() {
        if (connector != null)
            connector.shutdown();
        if (executor != null)
            executor.shutdown();
    }

    public void run(int a_numThreads) {
        Map<String, Integer> topicCountMap = new HashMap<String, Integer>();
        topicCountMap.put(topic, new Integer(a_numThreads));
        Map<String, List<KafkaStream<byte[], byte[]>>> consumerMap = connector.createMessageStreams(topicCountMap);
        List<KafkaStream<byte[], byte[]>> streams = consumerMap.get(topic);

        executor = Executors.newFixedThreadPool(a_numThreads);

        int threadNumber = 0;
        for (KafkaStream<byte[], byte[]> stream : streams) {
            executor.submit(new ConsumerRunnable(stream, threadNumber));
            threadNumber++;
        }
    }

    private static ConsumerConfig createConsumerConfig(String a_zookeeper, String a_groupId) {
        Properties props = new Properties();
        props.put("zookeeper.connect", a_zookeeper);
        props.put("group.id", a_groupId);
        props.put("zookeeper.session.timeout.ms", "400");
        props.put("zookeeper.sync.time.ms", "200");
        props.put("auto.commit.interval.ms", "1000");

        return new ConsumerConfig(props);
    }

    public class ConsumerRunnable implements Runnable {
        private KafkaStream<byte[], byte[]> m_stream;
        private int m_threadNumber;

        public ConsumerRunnable(KafkaStream<byte[], byte[]> stream, int a_threadNumber) {
            m_threadNumber = a_threadNumber;
            m_stream = stream;
        }

        @Override
        public void run() {
            ConsumerIterator<byte[], byte[]> it = m_stream.iterator();
            while (it.hasNext()) {

                System.out.println(new Date() + " : consumerNum : " + consumerNum + " : message received... : "
                        + new String(it.next().message()) + " Thread : " + m_threadNumber);

                if (--count == 0) {
                    consumer.shutdown();
                }
            }
            System.out.println("finish!");
        }
    }
}
